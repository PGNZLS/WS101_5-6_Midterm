`<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    </header
    <center>
<body style="background-color:#728FCE">
        <form class="" action="dashboard" method="POST">
        @csrf
    <center>
    <h1>DASHBOARD</h1>
    <nav>
    <a href="{{url('dashboard')}}">Dashboard</a>
    <a href="{{url('transaction')}}">Transaction</a>
    </nav>
    </center>
    <center>
        <br><br><br>
        <center>
        <br><br><br>
        `<h1>Name: Prince AL Gonzales</h1>
        <h1>ID Number: 59821921</h1>
        <h1>Balance: 3,000 </h1>`
    </center>
</body>
    </center>
            
        </form>
</body>
</center>
</html>

